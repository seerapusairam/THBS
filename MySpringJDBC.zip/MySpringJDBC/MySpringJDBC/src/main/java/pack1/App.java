package pack1;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext contex = new ClassPathXmlApplicationContext("beans.xml");
        
        EmployeeDAO emp1=(EmployeeDAO) contex.getBean("EmployeeDAO");
        
        Employee emp=new Employee();
//        emp.setEmployeeId(120);
//        emp.setEmployeeName("sairam");
//        emp.setSalary(70000);
//        emp1.insert(emp);
        
//        ArrayList<Employee> elist = (ArrayList<Employee>) emp1.selectAll();
//        for(Employee e:elist) {
//        	System.out.println(e);
//        }
        
        Employee employee=emp1.selectAEmployee(120);
        System.out.println(employee);
        
        
    }
}
