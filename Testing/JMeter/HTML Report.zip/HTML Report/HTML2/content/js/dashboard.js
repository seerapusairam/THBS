/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 82.06349206349206, "KoPercent": 17.936507936507937};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.0017513134851138354, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "3 login"], "isController": true}, {"data": [0.0, 500, 1500, "7 click_flights"], "isController": false}, {"data": [0.0, 500, 1500, "5 login"], "isController": false}, {"data": [0.009569377990430622, 500, 1500, "11 sign off"], "isController": true}, {"data": [0.0, 500, 1500, "8 click_flights"], "isController": false}, {"data": [0.0, 500, 1500, "4 login"], "isController": false}, {"data": [0.0, 500, 1500, "12 sign off"], "isController": false}, {"data": [0.0, 500, 1500, "1 launch_app"], "isController": true}, {"data": [0.0, 500, 1500, "2 launch_app"], "isController": false}, {"data": [0.004201680672268907, 500, 1500, "6 click_flights"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2520, 452, 17.936507936507937, 9034.06666666668, 0, 37973, 10858.8, 13947.0, 26863.53999999998, 8.923797146509626, 14.928692896108586, 3.354401980542935], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Throughput", "Received", "Sent"], "items": [{"data": ["3 login", 538, 538, 100.0, 17402.511152416344, 4849, 41434, 28322.7, 32375.649999999998, 35612.3, 2.0225563909774436, 4.376942111137218, 1.7984499823778195], "isController": true}, {"data": ["7 click_flights", 217, 6, 2.7649769585253456, 8749.336405529948, 2674, 18627, 10349.0, 14223.799999999997, 17968.12, 1.0229962002998274, 1.7719111083480261, 0.3856446334538614], "isController": false}, {"data": ["5 login", 259, 10, 3.861003861003861, 8507.347490347494, 163, 15594, 10334.0, 11806.0, 15275.8, 1.0250078161792933, 1.7795025521309475, 0.36568773967967516], "isController": false}, {"data": ["11 sign off", 418, 34, 8.133971291866029, 12754.126794258373, 0, 32797, 18484.0, 19692.749999999996, 27496.79, 2.0226948295468294, 3.84871146959909, 1.058073842878227], "isController": true}, {"data": ["8 click_flights", 223, 6, 2.690582959641256, 8606.206278026906, 78, 17866, 10041.8, 12540.399999999978, 17230.639999999978, 1.012320347185023, 4.41326133980371, 0.3828740676892767], "isController": false}, {"data": ["4 login", 249, 10, 4.016064257028113, 8785.86746987951, 57, 17992, 11239.0, 12320.5, 16835.5, 1.0271048430674548, 1.2175318920694307, 0.3610311227720281], "isController": false}, {"data": ["12 sign off", 194, 7, 3.6082474226804124, 8633.520618556702, 339, 18000, 10251.0, 11074.0, 17994.3, 0.990791765192566, 1.7247984102643985, 0.3562752645516157], "isController": false}, {"data": ["1 launch_app", 574, 27, 4.70383275261324, 12888.581881533097, 17, 30411, 19236.5, 21144.0, 24434.25, 2.0330170468833564, 3.8469967895420045, 1.0542408959176734], "isController": true}, {"data": ["2 launch_app", 278, 9, 3.237410071942446, 8861.687050359715, 2119, 18006, 10881.199999999999, 12832.05, 17082.709999999977, 1.0194801384732735, 1.7730707518757702, 0.3708916245397671], "isController": false}, {"data": ["6 click_flights", 476, 44, 9.243697478991596, 16765.739495798323, 0, 40882, 26879.9, 32334.549999999996, 37741.11000000001, 2.058912582724166, 7.792359639257754, 1.447609548693715], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException", 9, 1.991150442477876, 0.35714285714285715], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 70, 15.486725663716815, 2.7777777777777777], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket operation on nonsocket: connect", 24, 5.3097345132743365, 0.9523809523809523], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to 18.221.250.120:1080 [\/18.221.250.120] failed: Connection timed out: connect", 9, 1.991150442477876, 0.35714285714285715], "isController": false}, {"data": ["Test failed: text expected to contain \/User password was correct\/", 255, 56.415929203539825, 10.119047619047619], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException", 69, 15.265486725663717, 2.738095238095238], "isController": false}, {"data": ["Assertion failed", 16, 3.5398230088495577, 0.6349206349206349], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2520, 452, "Test failed: text expected to contain \/User password was correct\/", 255, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 70, "Non HTTP response code: java.net.SocketException", 69, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket operation on nonsocket: connect", 24, "Assertion failed", 16], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["3 login", 299, 299, "Test failed: text expected to contain \/User password was correct\/", 255, "Assertion failed", 16, "Non HTTP response code: java.net.SocketException", 10, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 8, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException", 4], "isController": false}, {"data": ["7 click_flights", 217, 6, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 4, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket operation on nonsocket: connect", 2, null, null, null, null, null, null], "isController": false}, {"data": ["5 login", 259, 10, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 6, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket operation on nonsocket: connect", 4, null, null, null, null, null, null], "isController": false}, {"data": ["11 sign off", 231, 34, "Non HTTP response code: java.net.SocketException", 19, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 11, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket operation on nonsocket: connect", 2, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException", 1, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to 18.221.250.120:1080 [\/18.221.250.120] failed: Connection timed out: connect", 1], "isController": false}, {"data": ["8 click_flights", 223, 6, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 5, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket operation on nonsocket: connect", 1, null, null, null, null, null, null], "isController": false}, {"data": ["4 login", 249, 10, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 8, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket operation on nonsocket: connect", 2, null, null, null, null, null, null], "isController": false}, {"data": ["12 sign off", 194, 7, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 4, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket operation on nonsocket: connect", 3, null, null, null, null, null, null], "isController": false}, {"data": ["1 launch_app", 305, 27, "Non HTTP response code: java.net.SocketException", 18, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 5, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket operation on nonsocket: connect", 4, null, null, null, null], "isController": false}, {"data": ["2 launch_app", 278, 9, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 7, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket operation on nonsocket: connect", 2, null, null, null, null, null, null], "isController": false}, {"data": ["6 click_flights", 265, 44, "Non HTTP response code: java.net.SocketException", 22, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 12, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException", 4, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to 18.221.250.120:1080 [\/18.221.250.120] failed: Connection timed out: connect", 4, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket operation on nonsocket: connect", 2], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
