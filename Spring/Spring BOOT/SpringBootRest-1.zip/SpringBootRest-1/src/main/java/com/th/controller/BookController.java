package com.th.controller;

import java.util.List;
import com.th.model.*;
import com.th.repository.BookRepository;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/books")
public class BookController {
	
	@GetMapping("/getAllBooks")
	public ResponseEntity<List<Book>>getAllBooks() {
		BookRepository br = new BookRepository();
		List<Book>blist = br.getAllBooks();
		return new ResponseEntity<List<Book>>(blist,HttpStatus.OK);
	}
	
	@GetMapping("/getABook/{bookId}")
	public ResponseEntity<Book>getABook(@PathVariable int bookId){
		BookRepository br = new BookRepository();
		Book b = br.getABook(bookId);
		if(b!=null)
			return new ResponseEntity<Book>(b,HttpStatus.OK);
		else
			return new ResponseEntity<Book>(HttpStatus.NOT_FOUND);	
	}
}
