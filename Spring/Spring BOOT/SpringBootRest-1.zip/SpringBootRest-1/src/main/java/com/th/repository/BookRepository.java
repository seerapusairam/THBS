package com.th.repository;

import java.util.*;

import com.th.model.*;

public class BookRepository {

	List<Book> blist;
	
	public BookRepository() {
		blist = new ArrayList<Book>();
		 
		Book b1 =new Book();
		b1.setBookId(101);
		b1.setBookName("java");
		b1.setBookPrice(2500);
		
		Book b2 =new Book();
		b2.setBookId(102);
		b2.setBookName("HTML");
		b2.setBookPrice(3000);
		
		Book b3 =new Book();
		b3.setBookId(103);
		b3.setBookName("JavaScript");
		b3.setBookPrice(4500);
		
		blist.add(b1);
		blist.add(b2);
		blist.add(b3);
	}
	
	public List<Book> getAllBooks(){
		return blist;
	}
	
	public Book getABook(int bookId) {
		for(Book b:blist) 
			if(b.getBookId()==bookId) {
				return b;
			}
			return null;
	}
}
