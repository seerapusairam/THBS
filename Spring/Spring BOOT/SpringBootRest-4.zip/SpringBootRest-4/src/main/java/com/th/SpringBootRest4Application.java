package com.th;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRest4Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRest4Application.class, args);
	}

}
