package com.th;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRest4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
