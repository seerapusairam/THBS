package com.th.controller;

import java.util.List;
import com.th.model.*;
import com.th.repository.PersonRepository;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/person")
public class PersonController {

	@GetMapping("/getAllPersons")
	public ResponseEntity<List<Person>> getAllPersons(){
		PersonRepository pr = new PersonRepository();
		List<Person> plist = pr.getAllPersons();
		return new ResponseEntity<List<Person>>(plist,HttpStatus.OK);
	}
}
