package com.th.repository;

import java.util.ArrayList;
import java.util.List;

import com.th.model.*;

public class PersonRepository {
	
	List<Person> plist;
	
	public PersonRepository() {
		plist = new ArrayList<Person>();
		
		Person p1 = new Person();
		p1.setPersonId(501);
		p1.setPersonName("sairam");
		p1.setPersonAge(23);
		
		Person p2 = new Person();
		p2.setPersonId(502);
		p2.setPersonName("vishnu");
		p2.setPersonAge(45);
		
		Person p3 = new Person();
		p3.setPersonId(503);
		p3.setPersonName("Lav");
		p3.setPersonAge(12);
		
		Person p4 = new Person();
		p4.setPersonId(504);
		p4.setPersonName("nani");
		p4.setPersonAge(40);
		
		plist.add(p1);
		plist.add(p2);
		plist.add(p3);
		plist.add(p4);
	}
	
	public List<Person> getAllPersons(){
		return plist;
	}
	
	
	

}
