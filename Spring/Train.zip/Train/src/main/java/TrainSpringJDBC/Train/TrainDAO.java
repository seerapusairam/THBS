//package TrainSpringJDBC.Train;
//
//import model.Train;
//
//import java.sql.*;
//
//public class TrainDAO {
//    public static Connection con = DBManager.getConnection();
//
//    public static Train findTrain(int trainNum) throws SQLException {
//        Statement st = con.createStatement();
//        ResultSet rs = st.executeQuery("select * from trains where train_no =" + trainNum);
//        rs.next();
//        return new Train(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getDouble(5));
//    }
//}

package TrainSpringJDBC.Train;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import TrainSpringJDBC.Train.*;

public class TrainDAO {
       private JdbcTemplate jdbcTemplate;
	
	public TrainDAO(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	
	public void insert(Train train) {
		
		if (null != train) {

         // Prepared statement in JDBC : insert statement below 			
			jdbcTemplate.update(
					"insert into trains values(?,?,?,?,?)",
					new Object[] { train.getTrainNo(),train.getTrainName(),train.getSource(),train.getDestination(),train.getTicketPrice() });
		
	}
		
	}
	
public List<Train> selectAll(){
		
		return	jdbcTemplate.query("select * from trains", new RowMapper<Train>() {
            // ResultSet rs = st.executeQuery("Select * from employee");
			
			
			@Override
			public Train mapRow(ResultSet resultSet, int arg1) throws SQLException {
				Train train = new Train();
				train.setTrainNo(resultSet.getInt(1));
				train.setTrainName(resultSet.getString(2));
				train.setSource(resultSet.getString(3));
				train.setDestination(resultSet.getString(4));
				train.setTicketPrice(resultSet.getInt(5));
				return train;

			}
		});
		}

}
