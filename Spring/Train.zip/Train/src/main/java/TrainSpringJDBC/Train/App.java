package TrainSpringJDBC.Train;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	 ApplicationContext ctx=new ClassPathXmlApplicationContext("file:src/main/java/beans.xml");  
         
    	 TrainDAO dao=(TrainDAO)ctx.getBean("trainDAO");  
    	 Train train = new Train();
    	 train.setTrainNo(1111);
    	 train.setTrainName("Express");
    	 train.setSource("RJY");
    	 train.setDestination("BZA");
    	 train.setTicketPrice(2500);
    	 dao.insert(train);
    	 
//    	 for(Train search:dao.selectAll()) {
//    		 System.out.println(search.getTrainNo()+" "+search.getTrainName()+" "+search.getSource()+" "+search.getDestination()+" "+search.getTicketPrice());
//           	 }
    	 
//    	 Train search = dao.select(1001);
//    	 System.out.println(search.getTrainNo()+" "+search.getTrainName()+" "+search.getSource()+" "+search.getDestination()+" "+search.getTicketPrice());
    	 
    	 ((ClassPathXmlApplicationContext)ctx).close();
    	 
    }
}
