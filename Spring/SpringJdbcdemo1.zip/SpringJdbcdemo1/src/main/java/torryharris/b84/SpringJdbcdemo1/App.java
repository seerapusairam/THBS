package torryharris.b84.SpringJdbcdemo1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	 ApplicationContext ctx=new ClassPathXmlApplicationContext("file:src/main/java/beans.xml");  
         
    	 BookDAO1 dao=(BookDAO1)ctx.getBean("bookDAO");  
//    	 Book book = new Book();
//    	 book.setBookId(200);
//    	 book.setBookName("Java");
//    	 book.setBookPrice(2000);
//    	 dao.insert(book);
    	 
    	 for(Book b:dao.selectAll()) {
    		 System.out.println(b.getBookId()+" "+b.getBookName()+" "+b.getBookPrice());
    	 }
    	 
//    	 Book search = dao.select(201);
//    	 System.out.println(search.getBookId()+" "+search.getBookName()+" "+search.getBookPrice());
    	 
    	 ((ClassPathXmlApplicationContext)ctx).close();
    	 
    }
}
