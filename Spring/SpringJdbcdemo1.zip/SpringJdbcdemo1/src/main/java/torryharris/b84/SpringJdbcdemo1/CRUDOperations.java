package torryharris.b84.SpringJdbcdemo1;

public interface CRUDOperations {
	
	public void insert(Book book);

}
