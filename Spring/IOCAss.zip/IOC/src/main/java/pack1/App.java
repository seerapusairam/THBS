package pack1;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
        context.scan("pack1");
        context.refresh();
        
        
        
        Address add=(Address)context.getBean("address");
        add.setDoorNo("21");
        add.setPincode("1234");
        add.setState("AP");
        add.setStreet("5th");
        
        Chair ch=(Chair)context.getBean("chair");
        ch.setColor("red");
        ch.setType("beanbag");
        
        Student st=(Student) context.getBean("student");
        st.setId("12");
        st.setName("sam");
        st.setAddress(add);
        st.setChair(ch);
        
        System.out.println(st);
    }
}
